<?php

$maxfiles = 25;
$maxfilesize = 2; 	// in MB
$queuefiles = 2;	// how many in parallel mode
