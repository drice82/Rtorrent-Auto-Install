﻿/*
 * PLUGIN FILEDROP
 *
 * Greek language file.
 *
 * Author: Chris Kanatas (ckanatas@gmail.com)
 */

 theUILang.doesntSupportHTML5	= "Πρόσθετο filedrop: Το πρόγραμμα περιήγησης που χρησιμοποιείτε δεν υποστηρίζει αποστολές αρχείων με χρήση HTML5. Το πρόσθετο απενεργοποιήθηκε.";
 theUILang.tooManyFiles 	= "Πρόσθετο filedrop: Πάρα πολλά αρχεία. Πρέπει να είναι <= ";
 theUILang.fileTooLarge 	= "είναι πολύ μεγάλο. Παρακαλώ κάντε αποστολή αρχείων μεγέθους μέχρι";

thePlugins.get("filedrop").langLoaded();