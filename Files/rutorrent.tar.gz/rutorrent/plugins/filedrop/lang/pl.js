﻿/*
 * PLUGIN FILEDROP
 *
 * Polish language file.
 *
 * Author: Dare (piczok@gmail.com)
 */

 theUILang.doesntSupportHTML5	= "Plugin filedrop: Twoja przeglądarka nie obsługuje uploadu plików HTML5. Plugin został wyłączony.";
 theUILang.tooManyFiles 	= "Plugin filedrop: Za dużo plików. Musi być <=";
 theUILang.fileTooLarge 	= "jest za duży. Proszę wysłać pliki maksymalnie do";

thePlugins.get("filedrop").langLoaded();
