﻿/*
 * PLUGIN FILEDROP
 *
 * Turkish language file.
 *
 * Author: 
 */

 theUILang.doesntSupportHTML5	= "Plugin filedrop: Your browser does not support HTML5 file uploads. Plugin was disabled.";
 theUILang.tooManyFiles 	= "Plugin filedrop: Too many files. Must be <= ";
 theUILang.fileTooLarge 	= "is too large. Please upload files up to";

thePlugins.get("filedrop").langLoaded();