﻿/*
 * PLUGIN FEEDS
 *
 * Hungarian language file.
 *
 * Author: Tiby08
 */

 theUILang.feedAll		= "Összes torrent";
 theUILang.feedCompleted	= "Befejezett torrentek";
 theUILang.feedDownloading	= "Letöltött torrentek";
 theUILang.feedActive		= "Aktív torrentek";
 theUILang.feedInactive 	= "Inaktív torrentek";
 theUILang.feedError		= "Hibás torrentek";

thePlugins.get("feeds").langLoaded();