﻿/*
 * PLUGIN FEEDS
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.feedAll		= "Todos los torrents";
 theUILang.feedCompleted	= "Torrents completados";
 theUILang.feedDownloading	= "Torrents descargando";
 theUILang.feedActive		= "Torrents activos";
 theUILang.feedInactive 	= "Torrents inactivos";
 theUILang.feedError		= "Torrents con error";

thePlugins.get("feeds").langLoaded();