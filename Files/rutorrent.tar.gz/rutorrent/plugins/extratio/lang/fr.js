﻿/*
 * PLUGIN EXTRATIO
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.ratioRulesManager	= "Gestionnaire de règles";
 theUILang.mnu_ratiorule	= "Règle de ratio";
 theUILang.ratAddRule		= "Ajout";
 theUILang.ratDelRule		= "Suppr.";
 theUILang.ratUpRule		= "Haut";
 theUILang.ratDownRule		= "Bas";
 theUILang.ratioIfLegend	= "Si";
 theUILang.ratLabelContain	= "L'étiquette du torrent contient";
 theUILang.ratTrackerContain	= "Une des URLs de tracker du torrent contient";
 theUILang.ratTrackerPublic	= "Tous les trackers du torrent sont publics";
 theUILang.ratTrackerPrivate	= "Une des trackers du torrent est privé";
 theUILang.ratioThenLegend	= "Alors";
 theUILang.setRatioTo		= "Groupe de ratio";
 theUILang.setChannelTo 	= "Groupe de vitesse";
 theUILang.ratioNewRule 	= "Nouvelle rêgle";

thePlugins.get("extratio").langLoaded();