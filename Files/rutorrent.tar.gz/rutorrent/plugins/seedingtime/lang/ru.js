﻿/*
 * PLUGIN SeedingTime
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.seedingTime		= "Завершен";
 theUILang.addTime		= "Добавлен";

thePlugins.get("seedingtime").langLoaded();