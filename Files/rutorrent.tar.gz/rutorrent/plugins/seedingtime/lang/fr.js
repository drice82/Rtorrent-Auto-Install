﻿/*
 * PLUGIN SeedingTime
 *
 * French language file.
 *
 * Author: Nicobubulle (nicobubulle@gmail.com)
 */

 theUILang.seedingTime		= "Terminé";
 theUILang.addTime		= "Ajouté";

thePlugins.get("seedingtime").langLoaded();