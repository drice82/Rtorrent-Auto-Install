﻿/*
 * PLUGIN SeedingTime
 *
 * Turkish language file.
 *
 * Author: 
 */

 theUILang.seedingTime		= "Finished";
 theUILang.addTime		= "Added";

thePlugins.get("seedingtime").langLoaded();