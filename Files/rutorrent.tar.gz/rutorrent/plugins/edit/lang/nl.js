﻿/*
 * PLUGIN EDIT
 *
 * Dutch language file.
 *
 * Author: rascalli (rascallim@gmail.com)
 */

 theUILang.EditTrackers 		= "Bewerk torrent ...";
 theUILang.EditTorrentProperties	= "Torrent Eigenschappen";
 theUILang.errorAddTorrent		= "Fout bij het toevoegen van het torrent-bestand";
 theUILang.errorWriteTorrent		= "Fout bij schrijven van het torrent bestand";
 theUILang.errorReadTorrent		= "Fout bij het lezen van het torrent bestand";
 theUILang.cantFindTorrent		= "Bron torrent-bestand voor deze download niet gevonden."

thePlugins.get("edit").langLoaded();