﻿/*
 * PLUGIN DISKSPACE
 *
 * Vietnamese language file.
 *
 * Author: Ta Xuan Truong (truongtx8 AT gmail DOT com)
 */

 theUILang.diskNotification = "Chú ý! Ổ đĩa đầy. rTorrent có thể chạy không ổn định, và sẽ không có dữ liệu nào được tải về thêm cho tới khi bạn dọn bớt ổ đĩa.";

thePlugins.get("diskspace").langLoaded();