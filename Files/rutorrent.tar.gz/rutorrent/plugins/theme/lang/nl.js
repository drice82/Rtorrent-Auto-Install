﻿/*
 * PLUGIN THEME
 *
 * Dutch language file.
 *
 * Author: 
 */

 theUILang.themeStandard	= "Standard";
 theUILang.theme		= "Theme";

thePlugins.get("theme").langLoaded();