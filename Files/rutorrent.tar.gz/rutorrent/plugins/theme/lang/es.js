﻿/*
 * PLUGIN THEME
 *
 * Spanish language file.
 *
 * Author: 
 */

 theUILang.themeStandard	= "Standard";
 theUILang.theme		= "Tema";

thePlugins.get("theme").langLoaded();