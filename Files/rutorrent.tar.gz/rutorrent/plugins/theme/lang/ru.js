﻿/*
 * PLUGIN THEME
 *
 * Russian language file.
 *
 * Author: 
 */

 theUILang.themeStandard	= "Стандартная";
 theUILang.theme		= "Палитра";

thePlugins.get("theme").langLoaded();