﻿/*
 * PLUGIN THEME
 *
 * Chinese Simplified language file.
 *
 * Author: 
 */

 theUILang.themeStandard	= "标准";
 theUILang.theme		= "主题";

thePlugins.get("theme").langLoaded();